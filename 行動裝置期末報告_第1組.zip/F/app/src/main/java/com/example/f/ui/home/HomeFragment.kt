package com.example.f.ui.home

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.f.*
import com.example.f.databinding.FragmentHomeBinding
import com.example.f.ui.MyDecoration
import org.jsoup.Jsoup
import java.util.*
import kotlin.collections.ArrayList

class HomeFragment : Fragment() {
    var course_number_list: ArrayList<String> = ArrayList<String>()
    lateinit var SearchArrayList: ArrayList<Course>
    var course_name_list: ArrayList<String> = ArrayList<String>()
    var course_code_list: ArrayList<String> = ArrayList<String>()
    var course_week_list: ArrayList<String> = ArrayList<String>()
    var course_session_list: ArrayList<String> = ArrayList<String>()

    //RecyclerView
    private lateinit var newRecyclerView: RecyclerView
    lateinit var newArrayList: ArrayList<Course>


    lateinit var t1: Thread

    //RecyclerView
    private var _binding: FragmentHomeBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?


    ): View {
        val homeViewModel =
            ViewModelProvider(this).get(HomeViewModel::class.java)

        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val sp_home_yaer = binding.spHomeYear
        var sp_home_yaer_str = ""
        var sp_home_class_str = ""
        var sp_home_depaerment_str = ""
        var sp_home_depaerment = binding.spHomeDepartment
        val sp_home_class = binding.spHomeClass
        var course_code = ""

        sp_home_yaer?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                sp_home_yaer_str = parent?.getItemAtPosition(position).toString()
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }
        sp_home_depaerment?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parent?.getItemAtPosition(position).toString()
                sp_home_depaerment_str = selectedItem

                change_spinner(selectedItem, sp_home_class)

            }

            private fun change_spinner(selectedItem: String, spClass: Spinner) {
                val class_noun_adapter =
                    context?.let {
                        ArrayAdapter.createFromResource(
                            it,
                            R.array.class_noun,
                            android.R.layout.simple_spinner_item
                        )
                    }
                val class_bio_adapter =
                    context?.let {
                        ArrayAdapter.createFromResource(
                            it,
                            R.array.class_bio,
                            android.R.layout.simple_spinner_item
                        )
                    }
                val class_doctor_adapter =
                    context?.let {
                        ArrayAdapter.createFromResource(
                            it,
                            R.array.class_doctor,
                            android.R.layout.simple_spinner_item
                        )
                    }
                val class_manage_adapter =
                    context?.let {
                        ArrayAdapter.createFromResource(
                            it,
                            R.array.class_manage,
                            android.R.layout.simple_spinner_item
                        )
                    }
                val class_soci_adapter =
                    context?.let {
                        ArrayAdapter.createFromResource(
                            it,
                            R.array.class_soci,
                            android.R.layout.simple_spinner_item
                        )
                    }
                val class_tech_adapter =
                    context?.let {
                        ArrayAdapter.createFromResource(
                            it,
                            R.array.class_tech,
                            android.R.layout.simple_spinner_item
                        )
                    }
                val class_techer_adapter =
                    context?.let {
                        ArrayAdapter.createFromResource(
                            it,
                            R.array.class_techer,
                            android.R.layout.simple_spinner_item
                        )
                    }
                val class_virtual_adapter =
                    context?.let {
                        ArrayAdapter.createFromResource(
                            it,
                            R.array.class_virtual,
                            android.R.layout.simple_spinner_item
                        )
                    }

                if (selectedItem == "農學院") spClass?.adapter = class_noun_adapter
                if (selectedItem == "生命科學院") spClass?.adapter = class_bio_adapter
                if (selectedItem == "獸醫學院") spClass?.adapter = class_doctor_adapter
                if (selectedItem == "管理學院") spClass?.adapter = class_manage_adapter
                if (selectedItem == "人文藝術學院") spClass?.adapter = class_soci_adapter
                if (selectedItem == "理工學院") spClass?.adapter = class_tech_adapter
                if (selectedItem == "師範學院") spClass?.adapter = class_techer_adapter
                if (selectedItem == "虛擬學院") spClass?.adapter = class_virtual_adapter
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }
        sp_home_class?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                val selectedItem = parent?.getItemAtPosition(position).toString()
                sp_home_class_str=selectedItem
                val split_selectItem = selectedItem.split(" ").toTypedArray()
                course_code = split_selectItem[0]
                k(sp_home_yaer_str, course_code,sp_home_depaerment_str,sp_home_class_str)

            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }

        }
        k(sp_home_yaer_str, course_code,sp_home_depaerment_str,sp_home_class_str)
        return root
    }

    private fun k(sp_home_yaer_str: String, course_code: String,sp_home_depaerment_str:String,sp_home_class_str: String) {
        getWeb(sp_home_yaer_str, course_code)
        newRecyclerView = binding.courseList
        newRecyclerView.layoutManager = LinearLayoutManager(activity)
        newArrayList = arrayListOf<Course>()
        newRecyclerView.addItemDecoration(MyDecoration())
        SearchArrayList = arrayListOf<Course>()

        t1.join()
        gewUserData(sp_home_yaer_str, sp_home_depaerment_str,sp_home_class_str)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun gewUserData(sp_home_year_str: String, sp_home_depaerment_str: String, sp_home_class_str: String) {
        for (i in course_name_list.indices) {
            val course = Course(course_number_list[i], course_name_list[i])
            newArrayList.add(course)
        }
        SearchArrayList.addAll(newArrayList)
        var adapter = Myadapter(newArrayList)
        newRecyclerView.adapter = adapter
        adapter.setOnItemClickListener(object : Myadapter.onItemClickListener {

            override fun onItemClick(position: Int) {

                val intent = Intent(activity, DetailActivity::class.java)
                intent.putExtra("course_code", course_code_list[position])
                intent.putExtra("course_name", course_name_list[position])
                intent.putExtra("teacher_name", course_number_list[position])
                intent.putExtra("course_week", course_week_list[position])
                intent.putExtra("course_session", course_session_list[position])
                intent.putExtra("course_year",sp_home_year_str)
                intent.putExtra("department",sp_home_depaerment_str)
                intent.putExtra("class",sp_home_class_str)
                println("AOAO")
                println(sp_home_class_str)
                println("AOAO")
                startActivity(intent)
            }

        })
    }

    private fun getWeb(year_str: String, class_code: String) {
        t1 = Thread {
            if (this::SearchArrayList.isInitialized) {
                SearchArrayList.clear()
                SearchArrayList.clear()
                course_name_list.clear()
                course_code_list.clear()
                course_week_list.clear()
                course_session_list.clear()
                course_number_list.clear()
            }

            println("time start")
            var url =
                "https://david0970.herokuapp.com/get_course?course_class_id=" + class_code + "&course_year=" + year_str
            var doc = Jsoup.connect(url).get()
            println()
            Log.v("body", doc.body().toString());
            Log.v("Create Android", "Test");
            //val class_name: Elements = doc.select("class_name[]")
            val body: String = doc.body().toString()
            Regex("\"course_name\": \"([^\"]*)").findAll(body)
                .forEach { course_name_list.add(it.groupValues[1]) }
            Regex("\"course_code\": \"([^\"]*)\"").findAll(body)
                .forEach { course_code_list.add(it.groupValues[1]) }
            Regex("\"course_teacher\": \"([^\"]*)\"").findAll(body)
                .forEach { course_number_list.add(it.groupValues[1]) }
            Regex("\"course_week\": \"([^\"]*)\"").findAll(body)
                .forEach { course_week_list.add(it.groupValues[1]) }
            Regex("\"course_session\": \"([^\"]*)\"").findAll(body)
                .forEach { course_session_list.add(it.groupValues[1]) }
            println("Test:")
            println(course_number_list)
            println(course_name_list)
            println(course_code_list)
        }
        t1.start()
    }



}
