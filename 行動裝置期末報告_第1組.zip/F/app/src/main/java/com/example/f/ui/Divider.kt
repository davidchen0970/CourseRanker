package com.example.f.ui

import android.graphics.Canvas
import android.graphics.Rect
import android.nfc.cardemulation.HostNfcFService
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.example.f.MainActivity
import com.example.f.ui.home.HomeFragment

class MyDecoration : RecyclerView.ItemDecoration() {
    override fun onDraw(c: Canvas, parent: RecyclerView, state: RecyclerView.State) {
        super.onDraw(c, parent, state)
    }

    override fun onDrawOver(c: Canvas, parent: RecyclerView, state: RecyclerView.State) {
        super.onDrawOver(c, parent, state)
    }

    override fun getItemOffsets(
        outRect: Rect,
        view: View,
        parent: RecyclerView,
        state: RecyclerView.State
    ) {
        super.getItemOffsets(outRect, view, parent, state)
        outRect.set(0, 0, 0,10);    }
}