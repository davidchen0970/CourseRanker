package com.example.f

import android.os.Bundle
import android.os.Looper
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.navigation.ui.AppBarConfiguration
import com.example.f.databinding.ActivityDetailBinding
import org.jsoup.Jsoup

class DetailContent {


}