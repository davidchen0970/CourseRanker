package com.example.f

import android.app.Service
import android.content.Intent
import android.os.IBinder

class MyService : Service() {
    private var channel = ""
    private var text = ""
    private lateinit var thread: Thread

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        TODO("Return the communication channel to the service.")
        intent?.extras?.let {
            channel = it.getString("channel" , "")
            text = it.getString("text", "")
        }
        broadcast(
            when(channel)
            {
                "password" -> text
                "username" -> text
                else -> "error"
            }
        )
        return START_STICKY
    }


    private fun broadcast(msg:String) = sendBroadcast(Intent(channel).putExtra("msg" , msg))
}