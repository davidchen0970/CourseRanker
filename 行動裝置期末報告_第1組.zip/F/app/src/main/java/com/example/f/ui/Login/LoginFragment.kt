package com.example.f.ui.Login

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import android.widget.Toast.makeText
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.f.databinding.FragmentLoginBinding
import com.example.f.global_password
import com.example.f.global_username
import okhttp3.*
import java.io.IOException
import java.lang.Thread.sleep


class LoginFragment :Fragment() {

    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val loginViewModel =
            ViewModelProvider(this).get(LoginViewModel::class.java)

        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textLogin
        val login_button: Button = binding.login
        loginViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }
        val signup_button : Button = binding.signup

        login_button.setOnClickListener{submit_login()}
        signup_button.setOnClickListener{submit_signup()}

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun submit_login(){
        val ed_userName = binding.username
        val ed_password = binding.password
        val userName = ed_userName.text
        val password = ed_password.text
        val post_str :String = " https://david0970.herokuapp.com/login?user_name="+userName + "&status="+password
        val client = OkHttpClient()
        val request = Request.Builder()
            .url(post_str)
            .build()
        var gan = ""
        val t1 = Thread{
        client.newCall(request).enqueue(object :Callback{
            override fun onFailure(call: Call, e: IOException) {
                makeText(context, "Please try again...", Toast.LENGTH_SHORT).show()
            }

            override fun onResponse(call: Call, response: Response) {
                gan = response.body?.string().toString()
                println(gan)
            }
        })
        }
        t1.start()
        t1.join()
        sleep(2500)
        if(gan == "ok")
        {
            makeText(context, "Login Successful!", Toast.LENGTH_SHORT).show()
            global_password = password.toString()
            global_username = userName.toString()
        }
        else
        {
            makeText(context, "Please try again...", Toast.LENGTH_SHORT).show()
        }
    }

    fun submit_signup()
    {
        val username = binding.usernameSignup
        val nickname = binding.nicknameSignup
        val password = binding.passwordSignup

        val username_str = username.text
        val nickname_str = nickname.text
        val password_str = password.text
        if ( username_str.length == 0 || nickname_str.length == 0  || password_str.length == 0 ){
            makeText(context, "please confirm your information", Toast.LENGTH_SHORT).show()
        }
        else{
            val post_str :String = " https://david0970.herokuapp.com/" +
                    "signup?username="+ username_str+ "&status="+password_str+"&nickname="+nickname_str
            var receive_str = ""
            val client = OkHttpClient()
            val request = Request.Builder()
                .url(post_str)
                .build()
            client.newCall(request).enqueue(object :Callback{
                override fun onFailure(call: Call, e: IOException) {
                    TODO("Not yet implemented")
                }

                override fun onResponse(call: Call, response: Response) {
                    receive_str = response.body?.string().toString()
                }
            })
            sleep(2000)
            if(receive_str == "0"){
                makeText(context, "ok", Toast.LENGTH_SHORT).show()

            }
            else{
                makeText(context, "your username is used...", Toast.LENGTH_SHORT).show()
            }
        }
    }
}