package com.example.f

import android.os.Bundle
import android.os.SystemClock.sleep
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import org.jsoup.Jsoup
import java.io.IOException


class UpLoadActivity : AppCompatActivity() {

    var course_name_list: ArrayList<String> = ArrayList<String>()
    var course_code_list:ArrayList<String> = ArrayList<String>()
    lateinit var TextView_class:TextView
    lateinit var TextView_department:TextView
    lateinit var TextView_coursename:TextView
    lateinit var TextView_courseyear:TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_up_load)

        var course_id_str = "3470001"

        val adapter = ArrayAdapter.createFromResource(this,R.array.course_year,android.R.layout.simple_spinner_item)
        val department_adapter = ArrayAdapter.createFromResource(this,R.array.departmant,android.R.layout.simple_spinner_item)

        var course_year= intent.extras!!.getString("Course_year")
        var department = intent.extras!!.getString("Department")
        var CLASs= intent.extras!!.getString("Class")
        var course_name= intent.extras!!.getString("Course_name")
        var course_code= intent.extras!!.getString("Course_code")


        val submit_btn = findViewById<Button>(R.id.btn_submit)
        submit_btn.setOnClickListener{
            val ed_text= findViewById<EditText>(R.id.editTextTextPersonName2)
            disable_sp()
            val cool_text= findViewById<Spinner>(R.id.sp_cool).getSelectedItem().toString()
            val reward_text = findViewById<Spinner>(R.id.sp_reward).getSelectedItem().toString()
            val score_text = findViewById<Spinner>(R.id.sp_score).getSelectedItem().toString()
            val ed_text_str = ed_text.text.toString()
            if (course_code != null) {
                upload_comment( course_code , ed_text_str , cool_text , reward_text , score_text)
            }
            enable_sp()
        }


        TextView_class=findViewById(R.id.CLAss)
        TextView_courseyear=findViewById(R.id.courseyear)
        TextView_coursename=findViewById(R.id.course_name)
        TextView_department=findViewById(R.id.department)
        TextView_class.setText(CLASs)
        TextView_coursename.setText(course_name)
        TextView_department.setText(department)
        TextView_courseyear.setText(course_year)

        println(course_code)
        println(course_name)
        println(course_year)
        println(department)
        println(CLASs)



    }

    private fun disable_sp()
    {

        findViewById<Spinner>(R.id.sp_cool).isEnabled = false
        findViewById<Spinner>(R.id.sp_reward).isEnabled = false
        findViewById<Spinner>(R.id.sp_score).isEnabled = false

    }
    private fun enable_sp()
    {

        findViewById<Spinner>(R.id.sp_cool).isEnabled = true
        findViewById<Spinner>(R.id.sp_reward).isEnabled = true
        findViewById<Spinner>(R.id.sp_score).isEnabled = true

    }

    private fun upload_comment( course_code:String ,  content:String , cool:String , reward:String , score:String)
    {
        course_name_list.clear()

        val url = "https://david0970.herokuapp.com/upload_post?"
        val c_id_str = "course_code=" + course_code
        val cool_str = "&cool=" + cool
        val rewa_str = "&reward=" + reward
        val score_str = "&score=" + score
        val user_name = "&user_name=" + global_username
        val cont_str = "&content=" + content

        val post_str :String = url + c_id_str + cool_str + rewa_str + score_str + user_name + cont_str
        println(post_str)
        var receive_str = ""
        val client = OkHttpClient()
        val request = Request.Builder()
            .url(post_str)
            .build()
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                TODO("Not yet implemented")
            }

            override fun onResponse(call: Call, response: Response) {
                receive_str = response.body?.string().toString()
            }
        })
        sleep(2500)
        Toast.makeText(this, receive_str, Toast.LENGTH_SHORT).show()
    }


}