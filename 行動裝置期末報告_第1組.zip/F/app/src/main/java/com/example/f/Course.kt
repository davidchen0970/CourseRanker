package com.example.f

data class Course(var Title_course_number:String,var content_course_name:String)
