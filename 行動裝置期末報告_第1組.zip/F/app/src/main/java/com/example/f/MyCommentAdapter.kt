package com.example.f

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MyCommentAdapter (private val CommentList:ArrayList<Comment>):
    RecyclerView.Adapter<MyCommentAdapter.MyViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.comment_list,parent,false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
    val currentItem=CommentList[position]
        holder.reward.text=currentItem.Comment_reward
        holder.score.text=currentItem.Comment_score
        holder.cool.text=currentItem.Comment_cool
        holder.comment.text=currentItem.Comment
        holder.username.text=currentItem.Username

    }

    override fun getItemCount(): Int {
        return CommentList.size
    }
    class MyViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){

        val reward: TextView =itemView.findViewById(R.id.Comment_reward)
        val comment: TextView =itemView.findViewById(R.id.Comment)
        val cool: TextView =itemView.findViewById(R.id.Comment_cool)
        val score: TextView =itemView.findViewById(R.id.Comment_score)
        val username: TextView =itemView.findViewById(R.id.Username)


    }

}