package com.example.f

import android.R
import android.content.Intent
import android.os.Bundle
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.SearchView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.ui.AppBarConfiguration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.f.databinding.ActivityDetailBinding
import com.google.android.material.floatingactionbutton.FloatingActionButton
import org.jsoup.Jsoup


class DetailActivity : AppCompatActivity() {
    //RecyclerView
    private  lateinit var newRecyclerView: RecyclerView
    lateinit var newArrayList: ArrayList<Comment>

    var comment_list:ArrayList<String> = ArrayList<String>()
    var cool_list:ArrayList<String> = ArrayList<String>()
    var reward_list:ArrayList<String> = ArrayList<String>()
    var score_list:ArrayList<String> = ArrayList<String>()
    var username_list:ArrayList<String> = ArrayList<String>()

    lateinit var t2 :Thread
    //RecyclerView
    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityDetailBinding
    var score :String = String()
    var reward :String = String()
    var cool :String = String()
    var comment :ArrayList<String> = ArrayList<String>()
    var isNull :Boolean =true
    lateinit var TextView_reward:TextView
    lateinit var TextView_cool:TextView
    lateinit var TextView_score:TextView
    lateinit var TextView_content:TextView
    lateinit var TextView_coursename:TextView
    lateinit var TextView_teachername:TextView
    lateinit var TextView_coursetime:TextView
    lateinit var fab_home: FloatingActionButton
    var  body:String= String()
    var course_year :String="110"
    var department :String = "理工學院"
    var CLASs :String = "資工系"
     var coursename:String= String()
     var coursecode:String= String()
    val body_compare=Regex( "[\\[\\]]")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        var time: String = String()
        var coursecode: String = intent.extras!!.getString("course_code").toString()
        var coursename: String = intent.extras!!.getString("course_name").toString()
        var teachername: String? = intent.extras!!.getString("teacher_name")
        var courseweek: String? = intent.extras!!.getString("course_week")
        var coursesession: String? = intent.extras!!.getString("course_session")
        course_year=intent.extras!!.getString("course_year").toString()
        department=intent.extras!!.getString("department").toString()
        CLASs=intent.extras!!.getString("class").toString()
        val courseweeklist  = courseweek!!.split(' ')
        val coursessionlist =coursesession!!.split(' ')
        println(coursessionlist)
        println(courseweeklist)
        val timecount=courseweeklist.size
        val toast= Toast.makeText(applicationContext,coursecode, Toast.LENGTH_SHORT)
        toast.show()
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        TextView_teachername=binding.activityDetail.TeacherName
        TextView_coursename=binding.activityDetail.CourseName
        TextView_reward=binding.activityDetail.RatingReward
        TextView_cool=binding.activityDetail.RatingCool
        TextView_score=binding.activityDetail.RatingScore
        TextView_content=binding.activityDetail.Comment123
        TextView_coursetime=binding.activityDetail.CourseTime
        TextView_teachername.setText(teachername)
        TextView_coursename.setText(coursename)

        if (courseweeklist != null) {
            for( int in 0.. timecount-1){
                time=time+'['+courseweeklist[int]+']'+' '+coursessionlist[int]+' '

            }
        }
        TextView_coursetime.setText(time)
        getWeb(coursecode)
        //RecyclerView
        newRecyclerView=binding.activityDetail.CommentList
        newRecyclerView.layoutManager= LinearLayoutManager(this)
        newArrayList= arrayListOf<Comment>()
        //RecyclerView
        t2.join()

        gewUserData()
        fab_home =binding.activityDetail.fabHome
        fab_home.setOnClickListener{jumpToUpLoadPage(coursecode,coursename)}

    }

    private fun  getWeb(coursecode :String) {

        t2=Thread {

            var url = "https://david0970.herokuapp.com/get_post?course_code="+coursecode
            var doc = Jsoup.connect(url).get()

            println()
            Log.v("body", doc.body().toString());
            //val class_name: Elements = doc.select("class_name[]")
            body= doc.body().toString()
            println(body)
            val test ="[{\"score\": 1, \"reward\": 1, \"cool\": 2, \"content\": \"我好帥\",\"score\": 1, \"reward\": 2, \"cool\": 3, \"content\": \"我好帥\"}]"

            println("GOGO")

            try {

                val score_regex = "\"score\": (\\d+)".toRegex()
                val score_result: Sequence<MatchResult> = score_regex.findAll(body, 0)
                val score_map =
                    score_result.map { score_list.add(it.groupValues[1]) }.joinToString()

                val reward_regex = "\"reward\": (\\d+)".toRegex()
                val reward_result: Sequence<MatchResult> = reward_regex.findAll(body, 0)
                val reward_map =
                    reward_result.map { reward_list.add(it.groupValues[1]) }.joinToString()
                println(reward_list)

                val cool_regex = "\"cool\": (\\d+)".toRegex()
                val cool_result: Sequence<MatchResult> = cool_regex.findAll(body, 0)
                val cool_map =
                    cool_result.map { cool_list.add(it.groupValues[1]) }.joinToString()
                //cool_list.add(cool_map)
                println(cool_list)

                Regex("\"content\": \"([^\"]*)\"").findAll(body)
                    .forEach { comment_list.add(it.groupValues[1]).toString() }
                Regex("\"user_id\": \"([^\"]*)\"").findAll(body)
                    .forEach { username_list.add(it.groupValues[1]).toString() }



                println("Test:")
                println("username_list_indices : " + username_list.indices)
                println("username_list :" + username_list)
                println("Score_list :" + score_list)
                println("reward_list :" + reward_list)
                println("cool_list :" + cool_list)
                println("comment_list :" + comment_list)

                var Score_result :Int=0
                var Cool_result :Int=0
                var Reward_result :Int=0

                for(i in username_list.indices) {
                    Score_result=Score_result+score_list[i].toInt()
                    Reward_result=Reward_result+reward_list[i].toInt()
                    Cool_result=Cool_result+cool_list[i].toInt()

                }
                if(username_list.size!=0&&score_list.size!=0&&reward_list.size!=0&&cool_list.size!=0) {
                    println(username_list.size)
                    Score_result = Score_result / username_list.size
                    Cool_result = Cool_result / username_list.size
                    Reward_result = Reward_result / username_list.size
                    var Score: String = "甜度(" + Score_result.toString() + ")"
                    TextView_score.setText(Score)
                    var Cool: String = "涼度(" + Cool_result.toString() + ")"
                    TextView_cool.setText(Cool)
                    var Reward: String = "收穫(" + Reward_result.toString() + ")"
                    TextView_reward.setText(Reward)
                    var Comment_count: String = "課程心得(" + username_list.size.toString() + ")"
                    TextView_content.setText(Comment_count)
                }
            }
            catch(exception:IndexOutOfBoundsException){
                println("IndexOutOfBoundsException : no data in the class!!!")
                Log.e("DetailActivity","IndexOutOfBoundsException : no data in the class")

            }



        }
        t2.start()

    }
    private fun gewUserData() {
        for (i in comment_list.indices){
            val comment=Comment(username_list[i],"收穫("+reward_list[i]+")","甜度("+score_list[i]+")","涼度("+cool_list[i]+")",comment_list[i])
            newArrayList.add(comment)
        }

        var  adapter = MyCommentAdapter(newArrayList)
        newRecyclerView.adapter=adapter


    }
    private fun jumpToUpLoadPage(coursecode :String,coursename :String){

        if(global_username!="")
        {
            val intent =Intent(this,UpLoadActivity::class.java)
            intent.putExtra("Course_year",course_year )
            intent.putExtra("Department",department )
            intent.putExtra("Class",CLASs )
            intent.putExtra("Course_name",coursename )
            intent.putExtra("Course_code",coursecode )

            startActivity(intent)
        }
        else
        {

            Toast.makeText(this, "Please login to use the service.", Toast.LENGTH_SHORT).show()
        }
    }

}



