package com.example.f

data class Comment(var Username:String,var Comment_reward:String ,var Comment_score :String,var Comment_cool:String,var Comment:String)
